import { GetItemCommand, QueryCommand, UpdateItemCommand, TransactWriteItemsCommand, PutItemCommand } from "@aws-sdk/client-dynamodb";
import { marshall, unmarshall } from "@aws-sdk/util-dynamodb";
import { ddbClient } from "./ddbClient.js";
import { jwtDecode } from "jwt-decode";

const ERROR_MESSAGES = {
    WIN_LIMIT_EXCEEDED: 'User reached maximum win limit',
    PRIZES_LOCKED: 'Prize system is currently locked, please try again',
    NO_SPINS_REMAINING: 'No chances remaining'
};

export const handler = async (event) => {

    try {
        const authToken = event.headers.Authorization;
        const mobileNum = jwtDecode(authToken).sub;

        const storeId = event.queryStringParameters.storeId;

        const globalWinProb = await getGlobalWinProbability();
        if (!globalWinProb.result) throw new Error(globalWinProb.message);

        const storeWinProb = await getStoreWinProbability(storeId);
        if (!storeWinProb.result) throw new Error(storeWinProb.message);

        // update spin count when the user eligible to claim prize and return user limit
        const userLimits = await reduceSpinCountInDB(mobileNum);
        if (!userLimits.result) {
            throw new Error(userLimits.message);
        }

        const { remainingSpinCount, remainingWinCount } = userLimits.result;


        const didWin = checkWinStatus(globalWinProb.result, storeWinProb.result);
        if (!didWin.status) {
            return {
                statusCode: 200,
                headers: { 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({
                    status: false,
                    message: 'NO WIN',
                    spinsRemaining: remainingSpinCount,
                    winsRemaining: remainingWinCount
                }),
            };
        }


        // Lock the prize system before loading prizes
        const prizeLockId = storeId;
        const lockedPrizeRecord = await lockRecordInDB(prizeLockId);
        if (!lockedPrizeRecord.status) {
            throw new Error(lockedPrizeRecord.message);
        }

        const prizes = await loadEligiblePrizes(storeId);
        if (!prizes.result) {
            await unlockRecordInDB(prizeLockId);
            throw new Error(prizes.message);
        }


        const wonPrize = await selectPrizeByDistribution(prizes.result);
        if (!wonPrize.result) {
            await unlockRecordInDB(prizeLockId);
            throw new Error(wonPrize.message);
        }

        const couponCode = generateCouponCode();
        if (!couponCode.result) {
            await unlockRecordInDB(prizeLockId);
            throw new Error(couponCode.message);
        }

        // Perform transaction to update USER, PRIZE INVENTORY, USER_HISTORY, COUPON_HISTORY if Prize won
        const transactionResponse = await updateDataWithTransaction(mobileNum, wonPrize.result, couponCode.result, storeId);
        if (!transactionResponse.status) {
            await unlockRecordInDB(prizeLockId);
            throw new Error(transactionResponse.message);
        }

        // Unlock the prize system after successful transaction
        await unlockRecordInDB(prizeLockId);

        return {
            statusCode: 200,
            headers: { 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({
                status: didWin.result,
                prize: { Name: wonPrize.result.Name, ImageID: wonPrize.result.ImageID },
                couponCode: couponCode.result,
                winsRemaining: remainingWinCount - 1,
                spinsRemaining: remainingSpinCount
            }),
        };

    } catch (error) {
        console.error({ level: 'ERROR', message: 'Handler error', error });

        if (error.message === ERROR_MESSAGES.WIN_LIMIT_EXCEEDED) {
            return {
                statusCode: 400,
                headers: { 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ Message: 'NO WIN' }),
            };
        }

        if (error.message === ERROR_MESSAGES.NO_SPINS_REMAINING) {
            return {
                statusCode: 400,
                headers: { 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ Message: error.message }),
            };
        }

        return {
            statusCode: 500,
            headers: { 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ Message: 'Internal error' }),
        };
    }
};

const getGlobalWinProbability = async () => {
    const returnValue = { message: null, result: null };
    try {
        const input = {
            TableName: process.env.DYNAMODB_TABLE_NAME,
            Key: marshall({ PK: 'GLOBAL', SK: 'CONFIG' }),
            ProjectionExpression: 'OverallWinProb'
        };

        const command = new GetItemCommand(input);
        const db_response = await ddbClient.send(command);

        if (!db_response.Item || db_response.Item.OverallWinProb == undefined) throw new Error('Overall probability not found');

        const item = unmarshall(db_response.Item);

        if (item.OverallWinProb === 0) throw new Error('Overall probability is 0');

        returnValue.message = null;
        returnValue.result = item.OverallWinProb;
        return returnValue;

    } catch (error) {
        console.error(`Error in getRemainingWins:`, error);
        returnValue.result = null;
        returnValue.message = error.message;
        return returnValue;
    }
};

const getStoreWinProbability = async (storeId) => {
    const returnValue = { message: null, result: null };
    try {
        const input = {
            TableName: process.env.DYNAMODB_TABLE_NAME,
            Key: marshall({ PK: 'STORE', SK: storeId }),
            ProjectionExpression: 'OverallWinProb'
        };

        const command = new GetItemCommand(input);
        const db_response = await ddbClient.send(command);

        if (!db_response.Item || db_response.Item.OverallWinProb == undefined) throw new Error('Overall probability not found');

        const item = unmarshall(db_response.Item);

        if (item.OverallWinProb === 0) throw new Error('Overall probability is 0');

        returnValue.message = null;
        returnValue.result = item.OverallWinProb;
        return returnValue;

    } catch (error) {
        console.error(`Error in getStoreWinProbability:`, error);
        returnValue.result = null;
        returnValue.message = error.message;
        return returnValue;
    }
};

const loadEligiblePrizes = async (storeId) => {
    const returnValue = { message: null, result: null };
    try {
        const PK = `PRIZE#${storeId}`;

        const input = {
            TableName: process.env.DYNAMODB_TABLE_NAME,
            KeyConditionExpression: 'PK = :pk',
            FilterExpression: 'Active = :true AND AvailableStock > :zero',
            ProjectionExpression: 'SK, #Name, AvailableStock, ImageID',
            ExpressionAttributeNames: { '#Name': 'Name' },
            ExpressionAttributeValues: marshall({
                ':pk': PK,
                ':true': true,
                ':zero': 0
            })
        }

        const command = new QueryCommand(input);
        const db_response = await ddbClient.send(command);

        if (db_response.Count == 0) {
            throw new Error("No prizes configured");
        }

        const items = db_response.Items.map(item => unmarshall(item));

        returnValue.message = null;
        returnValue.result = items;
        return returnValue;

    } catch (error) {
        console.error(`Error in loadEligiblePrizes:`, error);
        returnValue.message = error.message;
        returnValue.result = null;
        return returnValue;
    }
};

const checkWinStatus = (globalWinProb, storeWinProb) => {
    const returnValue = { message: null, status: false };
    try {

        const probabilityRandom = Math.random();

        // here storeWinProb = 1 - 100, zero handled already, randomProbabilityValue = 1 - 10000
        const randomProbabilityValue = Math.floor(probabilityRandom * 10000) + 1;

        const winStatus = randomProbabilityValue <= (globalWinProb * storeWinProb);

        returnValue.message = null;
        returnValue.status = winStatus;
        return returnValue;

    } catch (error) {
        console.error(`Error in checkWinStatus:`, error);
        returnValue.status = false;
        returnValue.message = error.message;
        return returnValue;
    }
};

const reduceSpinCountInDB = async (mobileNum) => {
    const returnValue = { message: null, result: null };
    try {

        const PK = `USER`;
        const SK = `USER#${mobileNum}`;

        const input = {
            TableName: process.env.DYNAMODB_TABLE_NAME,
            Key: marshall({ PK: PK, SK: SK }),
            UpdateExpression: 'SET SpinsRemaining = SpinsRemaining - :one',
            ConditionExpression: 'SpinsRemaining > :zero',
            ExpressionAttributeValues: marshall({
                ':zero': 0,
                ':one': 1
            }),
            ReturnValues: 'ALL_NEW'
        };

        const command = new UpdateItemCommand(input);
        const db_response = await ddbClient.send(command);

        if (!db_response.Attributes) {
            throw new Error('Invalid user');
        }

        const item = unmarshall(db_response.Attributes);

        // Then check wins
        if (item.WinsRemaining === 0) {
            throw new Error(ERROR_MESSAGES.WIN_LIMIT_EXCEEDED);
        }

        returnValue.message = null;
        returnValue.result = {
            remainingSpinCount: item.SpinsRemaining,
            remainingWinCount: item.WinsRemaining
        };
        return returnValue;

    } catch (error) {
        console.error(`Error in reduceSpinCountInDB:`, error);
        // Check spins first (primary constraint)
        if (error.name === "ConditionalCheckFailedException") {
            returnValue.status = false;
            returnValue.message = ERROR_MESSAGES.NO_SPINS_REMAINING;
            return returnValue;
        }
        returnValue.result = null;
        returnValue.message = error.message;
        return returnValue;
    }
}

const selectPrizeByDistribution = async (prizes) => {
    const returnValue = { message: null, result: null };
    try {
        const totalStock = prizes.reduce((acc, prize) => acc + prize.AvailableStock, 0);

        const randomValue = Math.random();

        const randomStockPosition = Math.floor(randomValue * totalStock); // range: 0 to totalStock-1

        let cumulativeStock = 0;
        let selectedPrize;

        for (const prize of prizes) {
            cumulativeStock += prize.AvailableStock;
            if (randomStockPosition < cumulativeStock) {
                selectedPrize = prize;
                break;
            }
        }

        returnValue.result = selectedPrize;
        returnValue.message = null;
        return returnValue;

    } catch (error) {
        console.error(`Error in selectPrizeByDistribution:`, error);
        returnValue.result = null;
        returnValue.message = error.message;
        return returnValue;
    }
};

const generateCouponCode = () => {
    const returnValue = { message: null, result: null };
    try {
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let coupon = '';
        for (let i = 0; i < 12; i++) {
            const randomValue = Math.random();
            const randomIndex = Math.floor(randomValue * characters.length);
            coupon += characters.charAt(randomIndex);
        }

        returnValue.message = null;
        returnValue.result = coupon;
        return returnValue;

    } catch (error) {
        console.error('Error in generateCouponCode:', error);
        returnValue.message = error.message;
        returnValue.result = null;
        return returnValue;
    }
};


const updateDataWithTransaction = async (mobileNum, prize, couponCode, storeId) => {
    const returnValue = { message: null, status: false };
    try {
        const now = Date.now();

        // Update USER record for WinsRemaining
        const transactItems = [
            {
                Update: {
                    TableName: process.env.DYNAMODB_TABLE_NAME,
                    Key: marshall({ PK: `USER`, SK: `USER#${mobileNum}` }),
                    UpdateExpression: 'SET WinsRemaining = WinsRemaining - :one',
                    ConditionExpression: 'WinsRemaining > :zero',
                    ExpressionAttributeValues: marshall({
                        ':one': 1,
                        ':zero': 0
                    })
                }
            }
        ];

        // Update PRIZE INVENTORY record for AvailableStock
        transactItems.push({
            Update: {
                TableName: process.env.DYNAMODB_TABLE_NAME,
                Key: marshall({ PK: `PRIZE#${storeId}`, SK: prize.SK }),
                UpdateExpression: 'SET AvailableStock = AvailableStock - :one',
                ConditionExpression: 'AvailableStock > :zero AND Active = :true',
                ExpressionAttributeValues: marshall({
                    ':one': 1,
                    ':zero': 0,
                    ':true': true
                })
            }
        });

        // Add USER_HISTORY record
        transactItems.push({
            Put: {
                TableName: process.env.DYNAMODB_TABLE_NAME,
                Item: marshall({
                    PK: 'USER_HISTORY',
                    SK: `${mobileNum}#${couponCode}`,
                    Prize: {
                        Id: prize.SK,
                        Name: prize.Name,
                        ImageID: prize.ImageID,
                        WonTimestamp: now,
                        CouponCode: couponCode
                    },
                    StoreId: storeId,
                    MobileNumber: mobileNum,
                    IsMarked: false
                }),
                ConditionExpression: "attribute_not_exists(SK)"
            }
        });

        // Add COUPON_HISTORY record
        transactItems.push({
            Put: {
                TableName: process.env.DYNAMODB_TABLE_NAME,
                Item: marshall({
                    PK: `COUPON_HISTORY#${storeId}`,
                    SK: couponCode,
                    Prize: {
                        Id: prize.SK,
                        Name: prize.Name,
                        ImageID: prize.ImageID,
                        WonTimestamp: now,
                        CouponCode: couponCode
                    },
                    StoreId: storeId,
                    MobileNumber: mobileNum,
                    IsMarked: false
                }),
                ConditionExpression: "attribute_not_exists(SK)"
            }
        });

        const command = new TransactWriteItemsCommand({ TransactItems: transactItems });

        await ddbClient.send(command);

        returnValue.message = null;
        returnValue.status = true;
        return returnValue;

    } catch (error) {
        console.error(`Error in updateDataWithTransaction:`, error);

        returnValue.status = false;
        returnValue.message = error.message;
        return returnValue;
    }
};

async function lockRecordInDB(lockId) {
    const returnValue = { message: null, status: false };
    try {
        const lockFor = parseInt(process.env.LOCK_TIME_LIMIT);
        const now = Date.now();
        const input = {
            TableName: process.env.DYNAMODB_TABLE_NAME,
            Key: marshall({ PK: `LOCK#${lockId}`, SK: `LOCK#${lockId}` }),
            ConditionExpression: "attribute_not_exists(lockedAt) OR (#lockedAt = :null) OR (#lockedAt <= :lockExpiredAt)",
            ExpressionAttributeNames: {
                "#lockedAt": "lockedAt"
            },
            ExpressionAttributeValues: marshall({
                ":now": now,
                ":null": null,
                ":lockExpiredAt": (now - lockFor)
            }),
            UpdateExpression: "SET #lockedAt = :now"
        };

        const command = new UpdateItemCommand(input);
        await ddbClient.send(command);

        returnValue.message = null;
        returnValue.status = true;
        return returnValue;

    } catch (error) {
        console.error(`Error in lockRecordInDB:`, error);

        if (error.name === "ConditionalCheckFailedException") {
            returnValue.status = false;
            returnValue.message = ERROR_MESSAGES.PRIZES_LOCKED;
            return returnValue;
        }

        returnValue.status = false;
        returnValue.message = error.message;
        return returnValue;
    }
}

async function unlockRecordInDB(lockId) {
    const returnValue = { message: null, status: false };
    try {
        const input = {
            Item: marshall({
                PK: `LOCK#${lockId}`,
                SK: `LOCK#${lockId}`,
                lockedAt: null
            }),
            TableName: process.env.DYNAMODB_TABLE_NAME
        };

        const command = new PutItemCommand(input);
        await ddbClient.send(command);

        returnValue.message = null;
        returnValue.status = true;
        return returnValue;

    } catch (error) {
        console.error(`Error in unlockRecordInDB:`, error);
        returnValue.message = error.message;
        returnValue.status = false;
        return returnValue;
    }
}


