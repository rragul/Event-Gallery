import { jwtVerify } from "jose";

export const handler = async (event) => {

  try {

    await verifyJwt(event.authorizationToken);

    const response = {
      "principalId": "user",
      "policyDocument": {
        "Version": "2012-10-17",
        "Statement": [
          {
            "Action": "execute-api:Invoke",
            "Effect": "Allow",
            "Resource": process.env.API_GATEWAY_ARN
          }
        ]
      }
    }

    return response;

  } catch (error) {
    // console.log(error.message);
    // return 'Unauthorized';
    const response = {
      "principalId": null,
      "policyDocument": {
        "Version": "2012-10-17",
        "Statement": [
          {
            "Action": "execute-api:Invoke",
            "Effect": "Deny",
            "Resource": process.env.API_GATEWAY_ARN
          }
        ]
      }
    }

    return response;
  }
};

async function verifyJwt(jwt) {

  const secret = Buffer.from(process.env.JWT_SECRET, "hex");

  return await jwtVerify(jwt, secret, {
    issuer: process.env.ISS,
    audience: process.env.ACC_AUD,
    algorithms: ["HS256"],
  });
}