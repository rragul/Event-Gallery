import { SignJWT } from "jose";

export const handler = async (event) => {

    try {
        const payload = { 
            type : "Guest Token"
        };

        const guestToken = await signJwt("Guest Token", payload);

        const response = {
            statusCode: 200,
            body: JSON.stringify({guestToken}),
            headers: {
                "Access-Control-Allow-Origin": "*"
            }
        };

        return response;

    } catch (error) {

        const response = {
            statusCode: 400,
            headers: {
                "Access-Control-Allow-Origin": "*"
            },
            body: error.message
        };

        return response;
    }
};

async function signJwt(subject, payload) {

    const secret = Buffer.from(process.env.JWT_SECRET, "hex");
  
    return new SignJWT(payload)
      .setProtectedHeader({ alg: "HS256" })
      .setSubject(subject)
      .setIssuedAt()
      .setIssuer(process.env.ISS)
      .setAudience(process.env.AUD)
      .setExpirationTime(process.env.EXP)//"12h"
      .sign(secret)
  };