import { SignJWT } from "jose";
import { GetItemCommand, UpdateItemCommand } from "@aws-sdk/client-dynamodb";
import { marshall, unmarshall } from "@aws-sdk/util-dynamodb";
import { ddbClient } from "./ddbClient.js";
import bcrypt from "bcryptjs";

export const handler = async (event) => {
  try {
    const payload = JSON.parse(event.body);
    const { mobileNumber, password } = payload;

    const user = await getUser(mobileNumber);
    if (!user) {
      throw { statusCode: 400, message: "Invalid login credentials" };
    }

    const passwordMatch = await bcrypt.compare(password, user.Signature);
    if (!passwordMatch) {
      throw { statusCode: 400, message: "Invalid login credentials" };
    }

    const accessToken = await getAccessToken(mobileNumber);
    const refreshToken = await getRefreshToken(mobileNumber);

    await updateRefreshToken(mobileNumber, refreshToken);

    return {
      statusCode: 200,
      body: JSON.stringify({
        accessToken,
        refreshToken,
      }),
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
    };
  } catch (error) {
    const statusCode = error.statusCode || 500;
    const message = error.message || "Internal error";
    console.error({ level: "ERROR", message: "Handler error", error });
    return {
      statusCode,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ message }),
    };
  }
};

async function getAccessToken(subject) {
  const secret = Buffer.from(process.env.JWT_SECRET, "hex");
  return await new SignJWT()
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(subject)
    .setIssuedAt()
    .setIssuer(process.env.ISS)
    .setAudience(process.env.ACC_AUD)
    .setExpirationTime(process.env.ACC_EXP)
    .sign(secret);
}

async function getRefreshToken(subject) {
  const secret = Buffer.from(process.env.JWT_SECRET, "hex");
  return await new SignJWT()
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(subject)
    .setIssuedAt()
    .setIssuer(process.env.ISS)
    .setAudience(process.env.REF_AUD)
    .setExpirationTime(process.env.REF_EXP)
    .sign(secret);
}

async function getUser(mobileNumber) {
  const PK = "USER";
  const SK = `USER#${mobileNumber}`;

  const input = {
    Key: marshall({ PK, SK }),
    TableName: process.env.DYNAMODB_TABLE_NAME,
    ProjectionExpression: "Signature",
  };

  const command = new GetItemCommand(input);
  const result = await ddbClient.send(command);

  if (!result.Item) return null;
  return unmarshall(result.Item);
}

async function updateRefreshToken(mobileNumber, refreshToken) {
  const PK = "USER";
  const SK = `USER#${mobileNumber}`;

  const input = {
    Key: marshall({ PK, SK }),
    ExpressionAttributeNames: { "#RefreshToken": "RefreshToken" },
    ExpressionAttributeValues: marshall({ ":RefreshToken": refreshToken }),
    UpdateExpression: "SET #RefreshToken = :RefreshToken",
    TableName: process.env.DYNAMODB_TABLE_NAME,
  };

  const command = new UpdateItemCommand(input);
  await ddbClient.send(command);
}
