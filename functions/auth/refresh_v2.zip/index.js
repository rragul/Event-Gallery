import { SignJWT, jwtVerify } from "jose";
import { UpdateItemCommand } from "@aws-sdk/client-dynamodb";
import { marshall } from "@aws-sdk/util-dynamodb";
import { ddbClient } from "./ddbClient.js";

export const handler = async (event) => {
  try {
    const payload = JSON.parse(event.body);

    const verified = await verifyRefreshJwt(payload.refreshToken);

    const mobileNumber = verified.payload.sub;

    const accessToken = await getAccessToken(mobileNumber);
    const refreshToken = await getRefreshToken(mobileNumber);

    await updateRefreshToken(mobileNumber, refreshToken, payload.refreshToken);

    return {
      statusCode: 200,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ accessToken, refreshToken }),
    };
  } catch (error) {
    console.error({ level: "ERROR", message: "Handler error", error });

    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ message: "Internal error" }),
    };
  }
};

async function verifyRefreshJwt(jwt) {
  const secret = Buffer.from(process.env.JWT_SECRET, "hex");

  return await jwtVerify(jwt, secret, {
    issuer: process.env.ISS,
    audience: process.env.REF_AUD,
    algorithms: ["HS256"],
  });
}

async function getAccessToken(subject) {
  const secret = Buffer.from(process.env.JWT_SECRET, "hex");

  return await new SignJWT()
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(subject)
    .setIssuedAt()
    .setIssuer(process.env.ISS)
    .setAudience(process.env.ACC_AUD)
    .setExpirationTime(process.env.ACC_EXP)
    .sign(secret);
}

async function getRefreshToken(subject) {
  const secret = Buffer.from(process.env.JWT_SECRET, "hex");

  return await new SignJWT()
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(subject)
    .setIssuedAt()
    .setIssuer(process.env.ISS)
    .setAudience(process.env.REF_AUD)
    .setExpirationTime(process.env.REF_EXP)
    .sign(secret);
}

async function updateRefreshToken(mobileNumber, refreshToken, existingRefreshToken) {
  const PK = "USER";
  const SK = `USER#${mobileNumber}`;

  const input = {
    TableName: process.env.DYNAMODB_TABLE_NAME,
    Key: marshall({ PK, SK }),
    ExpressionAttributeNames: { "#RefreshToken": "RefreshToken" },
    ExpressionAttributeValues: marshall({
      ":newToken": refreshToken,
      ":oldToken": existingRefreshToken,
    }),
    ConditionExpression: "#RefreshToken = :oldToken",
    UpdateExpression: "SET #RefreshToken = :newToken",
  };

  const command = new UpdateItemCommand(input);
  await ddbClient.send(command);
}
