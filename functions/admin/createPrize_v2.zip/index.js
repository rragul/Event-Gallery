import { PutItemCommand } from "@aws-sdk/client-dynamodb";
import { marshall } from "@aws-sdk/util-dynamodb";
import { ddbClient } from "./ddbClient.js";
import kuuid from "kuuid";

export const handler = async (event) => {
    try {
        const payload = JSON.parse(event.body);

        const prizeCreated = await createPrize(payload);
        if(!prizeCreated.result) throw new Error(prizeCreated.message);

        return {
            statusCode: 201,
            headers: { 'Access-Control-Allow-Origin': '*' },
        };

    } catch (error) {
        console.error({ level: 'ERROR', message: 'Handler error', error });
        return {
            statusCode: 500,
            headers: { 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: error.message }),
        };
    }
};


async function createPrize(payload) {
    const returnValue = { message: null, result: null };

    try{
        const prizeID = kuuid.id({
            random: 4,
            millisecond: true
        });
    
        const prizeItem = {
            PK: 'GLOBAL_PRIZE',
            SK: prizeID,
            Active: false,
            AvailableStock: payload.stock,
            InitialStock: payload.stock,
            ImageID: payload.imageID,
            LastUpdated: Date.now(),
            Name: payload.name
        };
    
        const input = {
            TableName: process.env.DYNAMODB_TABLE_NAME,
            Item: marshall(prizeItem)
        };
    
        const command = new PutItemCommand(input);
        await ddbClient.send(command);

        returnValue.result = 'success';
        return returnValue;
    } catch (error) {

        console.log(`Error createPrize(${payload}):`, error);
        const str = error["__type"];
        if (str) {
            const index = str.indexOf('#');
            const type = str.substring(index + 1);

            returnValue.message = type;
            return returnValue;
        }

        returnValue.message = error.message;
        return returnValue;
    }
  
}
